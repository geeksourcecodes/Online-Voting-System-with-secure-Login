<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>|| MZALENDO SYSTEM ||</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" type="image/png" href="../images/icons/favicon.png"/>
<link href="../default.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	color: #F8941D;
	font-weight: bold;
	font-size: 14px;
}
-->
</style>
</head>
<body>
<div id="header">
</div>
<div id="menu" align="center">
	<ul>
		<li><a href="../index.php">|  Home  |</a></li>
		<li><a href="../user_login.php">|  Voting  |</a></li>
		<li><a href="../result.php">|  Result  |</a></li>
		<li><a href="index.php">|  Backend  |</a></li>
		<li><a href="../contact.php">|  Contact Us  |</a></li>
        <li><a href="../index.php">|  Logout  |</a></li>
	</ul>
</div>

<p align="center" class="style1"> Mzalendo E-Voting System Admin Control Panel</p>
<div id="nav" align="center">
	<ul>
		<li><a href="position.php">|Position Info|</a></li>
		<li><a href="candidate.php">|Candidate Info|</a></li>
		<li><a href="students.php">|Voters Info|</a></li>
		<li><a href="tally.php">|Vote Analisys|</a></li>
        
	</ul>
</div>

<p>&nbsp;</p>
<div id="footer">
	<p>Copyright &copy; 2019 Designed by <a href="http://www.charlesmbuvi.com" class="link1">Charles Mbuvi</a></p>
</div>
</body>
</html>
