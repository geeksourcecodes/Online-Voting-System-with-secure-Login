	var	fixedX = -1		// x position (-1 if to appear below control)
	var	fixedY = -1			// y position (-1 if to appear below control)
	var startAt = 0			// 0 - sunday ; 1 - monday
	var showWeekNumber = 0	// 0 - don't show; 1 - show
	var showToday = 1		// 0 - don't show; 1 - show
	var imgDir = "images/"	// directory for images ... e.g. var imgDir="/img/"

	var gotoString = "Go To Current Month"
	var todayString = "<font color=white>Today is</font>"
	var weekString = "Wk"
	var scrollLeftMessage = "Click to scroll to previous month. Hold mouse button to scroll automatically."
	var scrollRightMessage = "Click to scroll to next month. Hold mouse button to scroll automatically."
	var selectMonthMessage = "Click to select a month."
	var selectYearMessage = "Click to select a year."
	var selectDateMessage = "Select [date] as date." // do not replace [date], it will be replaced by date.

	var	crossobj, crossMonthObj, crossYearObj, monthSelected, yearSelected, dateSelected, omonthSelected, oyearSelected, odateSelected, monthConstructed, yearConstructed, intervalID1, intervalID2, timeoutID1, timeoutID2, ctlToPlaceValue, ctlNow, dateFormat, nStartingYear

	var	bPageLoaded=false
	var	ie=document.all
	var	dom=document.getElementById

	var	ns4=document.layers
	var	today =	new	Date()
	var	dateNow	 = today.getDate()
	var	monthNow = today.getMonth()
	var	yearNow	 = today.getYear()
	var	imgsrc = new Array("drop1.gif","drop2.gif","left1.gif","left2.gif","right1.gif","right2.gif")
	var	img	= new Array()

	var bShow = false;
	
	//Short year status 28-FEB-2008 JIT
	var isShortYearFormat = false;

    /* hides <select> and <applet> objects (for IE only) */
    function hideElement( elmID, overDiv )
    {
      if( ie )
      {
        for( i = 0; i < document.all.tags( elmID ).length; i++ )
        {
          obj = document.all.tags( elmID )[i];
          if( !obj || !obj.offsetParent )
          {
            continue;
          }
      
          // Find the element's offsetTop and offsetLeft relative to the BODY tag.
          objLeft   = obj.offsetLeft;
          objTop    = obj.offsetTop;
          objParent = obj.offsetParent;
          
          while( objParent.tagName.toUpperCase() != "BODY" )
          {
            objLeft  += objParent.offsetLeft;
            objTop   += objParent.offsetTop;
            objParent = objParent.offsetParent;
          }
      
          objHeight = obj.offsetHeight;
          objWidth = obj.offsetWidth;
      
          if(( overDiv.offsetLeft + overDiv.offsetWidth ) <= objLeft );
          else if(( overDiv.offsetTop + overDiv.offsetHeight ) <= objTop );
          else if( overDiv.offsetTop >= ( objTop + objHeight ));
          else if( overDiv.offsetLeft >= ( objLeft + objWidth ));
          else
          {
            obj.style.visibility = "hidden";
          }
        }
      }
    }
     
    /*
    * unhides <select> and <applet> objects (for IE only)
    */
    function showElement( elmID )
    {
      if( ie )
      {
        for( i = 0; i < document.all.tags( elmID ).length; i++ )
        {
          obj = document.all.tags( elmID )[i];
          
          if( !obj || !obj.offsetParent )
          {
            continue;
          }
        
          obj.style.visibility = "";
        }
      }
    }

	function HolidayRec (d, m, y, desc)
	{
		this.d = d
		this.m = m
		this.y = y
		this.desc = desc
	}

	var HolidaysCounter = 0
	var Holidays = new Array()
	var topBarColor ="#84ACD5"
	var buttomBarColor = "#336699"
	var borderColor = "#006699"
	var bodyColor = "#FFFFFF"
	
	function addHoliday (d, m, y, desc)
	
	{
		Holidays[HolidaysCounter++] = new HolidayRec ( d, m, y, desc )
	}

	if (dom)
	{
		for	(i=0;i<imgsrc.length;i++)
		{
			img[i] = new Image
			img[i].src = imgDir + imgsrc[i]
		}
		document.write ("<div onclick='bShow=true'  id='calendar' onmouseover=\"document.all.close.src='"+imgDir+"close.gif'\" onmouseup=\"document.all.close.src='"+imgDir+"close.gif'\"	style='z-index:+999;position:absolute;visibility:hidden;'>")
		document.write("<table cellpadding=0 cellspacing=0 width="+((showWeekNumber==1)?250:200)+" style='font-family:arial;font-size:11px;border-width:1px;border-style:solid;border-color:"+borderColor+";font-family:arial; font-size:11px}' bgcolor='#ffffff'>")
		document.write("<tr bgcolor='"+topBarColor+"'><td><table cellpadding=2 cellspacing=0 width='"+((showWeekNumber==1)?248:218)+"' ><tr><td nowrap style='padding:2px;font-family:arial; font-size:11px;' align=right><font color='#000000'><B><span id='caption'></span></B></font></td><td nowrap align=right><a href='javascript:hideCalendar()' onmousedown=\"document.all.close.src='"+imgDir+"close2.gif'\" onmouseover='popDownYear(); popDownMonth();'><IMG id=close SRC='"+imgDir+"close.gif' WIDTH='16' HEIGHT='14' BORDER='0' ALT='Close the Calendar' align='absmiddle'></a>&nbsp;</td></tr></table></td></tr><tr><td style='padding:5px' bgcolor="+bodyColor+"><span id='content'></span></td></tr>")
			
		if (showToday==1)
		{
			document.write ("<tr bgcolor="+buttomBarColor+"><td style='padding:5px' align=center><span id='lblToday'></span></td></tr>")
		}
			
		document.write ("</table></div><div id='selectMonth' onmouseover=\"document.all.spanMonth.style.borderColor='#666666';\" style='z-index:+999;position:absolute;visibility:hidden;'></div><div id='selectYear' onmouseover=\"document.all.spanYear.style.borderColor='#666666';\" style='z-index:+999;position:absolute;visibility:hidden;'></div>");
	}
    
	//Full month name array variable
	var	monthName =	new	Array("January","February","March","April","May","June","July","August","September","October","November","December")
	//Short month name array variable 
	var	monthNameShort = new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
	
	if (startAt==0)
	{
		dayName = new Array	("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
	}
	else
	{
		dayName = new Array	("Mon","Tue","Wed","Thu","Fri","Sat","Sun")
	}
	var	styleAnchor="text-decoration:none;color:black;"
	var	styleLightBorder="border-style:solid;border-width:1px;border-color:#666666;"

	function swapImage(srcImg, destImg){
		if (ie)	{ document.getElementById(srcImg).setAttribute("src",imgDir + destImg) }
	}
	
	function dbqwikCalendarStd1init()	{
		if (!ns4)
		{
			if (!ie) { yearNow += 1900	}

			crossobj=(dom)?document.getElementById("calendar").style : ie? document.all.calendar : document.calendar
			hideCalendar()

			crossMonthObj=(dom)?document.getElementById("selectMonth").style : ie? document.all.selectMonth	: document.selectMonth

			crossYearObj=(dom)?document.getElementById("selectYear").style : ie? document.all.selectYear : document.selectYear

			monthConstructed=false;
			yearConstructed=false;

			if (showToday==1)
			{
				document.getElementById("lblToday").innerHTML =	todayString + " <a onmousemove='window.status=\""+gotoString+"\"' onmouseout='window.status=\"\"' title='"+gotoString+"' style='color: white' href='javascript:monthSelected=monthNow;yearSelected=yearNow;constructCalendar();'>"+dayName[(today.getDay()-startAt==-1)?6:(today.getDay()-startAt)]+", " + dateNow + " " + monthName[monthNow].substring(0,3)	+ "	" +	yearNow	+ "</a>"
			}

			sHTML1="&nbsp;<span id='spanLeft' style='border-style:solid;border-width:1;border-color:#D4D0C8;cursor:pointer' onmouseover='swapImage(\"changeLeft\",\"left2.gif\");this.style.borderColor=\"#666666\";window.status=\""+scrollLeftMessage+"\"; popDownYear(); popDownMonth();' onclick='javascript:decMonth()' onmouseout='clearInterval(intervalID1);swapImage(\"changeLeft\",\"left1.gif\");this.style.borderColor=\"#D4D0C8\";window.status=\"\"' onmousedown='clearTimeout(timeoutID1);timeoutID1=setTimeout(\"StartDecMonth()\",500)'	onmouseup='clearTimeout(timeoutID1);clearInterval(intervalID1)'>&nbsp<IMG id='changeLeft' SRC='"+imgDir+"left1.gif' width=10 height=11 align=middle BORDER=0>&nbsp</span>&nbsp;"
			sHTML1+="&nbsp;<span id='spanRight' style='border-style:solid;border-width:1;border-color:#D4D0C8;cursor:pointer'	onmouseover='swapImage(\"changeRight\",\"right2.gif\");this.style.borderColor=\"#666666\";window.status=\""+scrollRightMessage+"\"; popDownYear(); popDownMonth();' onmouseout='clearInterval(intervalID1);swapImage(\"changeRight\",\"right1.gif\");this.style.borderColor=\"#D4D0C8\";window.status=\"\"' onclick='incMonth()' onmousedown='clearTimeout(timeoutID1);timeoutID1=setTimeout(\"StartIncMonth()\",500)'	onmouseup='clearTimeout(timeoutID1);clearInterval(intervalID1)'>&nbsp<IMG id='changeRight' SRC='"+imgDir+"right1.gif'	width=10 height=11  align=middle BORDER=0>&nbsp</span>&nbsp"
			sHTML1+="&nbsp;<span id='spanMonth' style='width: 82px;border-style:solid;border-width:1;border-color:#D4D0C8;cursor:pointer'	onmouseover='swapImage(\"changeMonth\",\"drop2.gif\");this.style.borderColor=\"#666666\";window.status=\""+selectMonthMessage+"\"; popDownYear();' onmouseout='swapImage(\"changeMonth\",\"drop1.gif\");this.style.borderColor=\"#D4D0C8\";window.status=\"\"' onclick='popUpMonth()'></span>&nbsp;"
			sHTML1+="&nbsp;<span id='spanYear' style='border-style:solid;border-width:1;border-color:#D4D0C8;cursor:pointer' onmouseover='swapImage(\"changeYear\",\"drop2.gif\");this.style.borderColor=\"#666666\";window.status=\""+selectYearMessage+"\"; popDownMonth();' onmouseout='swapImage(\"changeYear\",\"drop1.gif\");this.style.borderColor=\"#D4D0C8\";window.status=\"\"'	onclick='popUpYear()'></span>&nbsp;"
			
			document.getElementById("caption").innerHTML  =	sHTML1

			bPageLoaded=true
		}
	}

	function hideCalendar()	{
		if (crossobj==null){
			return
		}
		crossobj.visibility="hidden"
		if (crossMonthObj != null){crossMonthObj.visibility="hidden"}
		if (crossYearObj !=	null){crossYearObj.visibility="hidden"}

	    showElement( 'SELECT' );
		showElement( 'APPLET' );
	}

	function padZero(num) {
		return (num	< 10)? '0' + num : num ;
	}

	function constructDate(d,m,y)
	{
		sTmp = dateFormat
		sTmp = sTmp.replace	("dd","<e>")
		sTmp = sTmp.replace	("d","<d>")
		sTmp = sTmp.replace	("<e>",padZero(d))
		sTmp = sTmp.replace	("<d>",d)
		sTmp = sTmp.replace	("mmmm","<o>")
		sTmp = sTmp.replace	("mmm","<j>") //jitfender
		sTmp = sTmp.replace	("mm","<n>")
		sTmp = sTmp.replace	("m","<m>")
		sTmp = sTmp.replace	("<m>",m+1)
		sTmp = sTmp.replace	("<n>",padZero(m+1))
		sTmp = sTmp.replace	("<o>",monthName[m])
		sTmp = sTmp.replace	("<j>",monthNameShort[m]) //jitfender
		return sTmp.replace ("yyyy",y)
	}

	function closeCalendar() {
		var	sTmp ;
		var strYearTemp = "";
		hideCalendar();
		//To support short year fotmat 28-FEB-2008 JIT
		if (isShortYearFormat){
		   strYearTemp = yearSelected + "";
		   yearSelected = strYearTemp.substring(2,4);;
		}
		sTmp = constructDate(dateSelected,monthSelected,yearSelected);
		if (dateFormat == "yyyymmdd") 
		{ 
		  sTmp = sTmp + "000000";
		} /* for hhmmss*/		
			
		ctlToPlaceValue.value = sTmp;	
	}

	/*** Month Pulldown	***/

	function StartDecMonth()
	{
		intervalID1=setInterval("decMonth()",80)
	}

	function StartIncMonth()
	{
		intervalID1=setInterval("incMonth()",80)
	}

	function incMonth () {
		monthSelected++
		if (monthSelected>11) {
			monthSelected=0
			yearSelected++
		}
		constructCalendar()
	}

	function decMonth () {
		monthSelected--
		if (monthSelected<0) {
			monthSelected=11
			yearSelected--
		}
		constructCalendar()
	}

	function constructMonth() {
		popDownYear()
		if (!monthConstructed) {
			sHTML =	""
			for	(i=0; i<12;	i++) {
				sName =	monthName[i];
				if (i==monthSelected){
					sName =	sName
				}
				sHTML += "<tr><td id='m" + i + "' onmouseover='this.style.backgroundColor=\"#CAD2E4\"; this.style.borderColor=\"#666666\"' onmouseout='this.style.backgroundColor=\"\"; this.style.borderColor=\"#FFFFFF\"' style='cursor:pointer; border: 1px solid #ffffff;' bgcolor=#ffffff onclick='monthConstructed=false;monthSelected=" + i + ";constructCalendar();popDownMonth();event.cancelBubble=true'>&nbsp;" + sName + "&nbsp;</td></tr>"
			}

			document.getElementById("selectMonth").innerHTML = "<table width=70 style='font-family:arial; font-size:11px; border-width:1; border-style:solid; border-color:#666666; border-Top: 0px;' bgcolor='#FFFFFF' cellspacing=1 cellpadding=0 onmouseover='clearTimeout(timeoutID1)'	onmouseout='clearTimeout(timeoutID1);timeoutID1=setTimeout(\"popDownMonth()\",100);event.cancelBubble=true'>" +	sHTML +	"</table>"

			monthConstructed=true
		}
	}

	function popUpMonth() {
		constructMonth()
		crossMonthObj.visibility = (dom||ie)? "visible"	: "show"
		leftOffset = parseInt(crossobj.left) + document.getElementById("spanMonth").offsetLeft + 12
		if (ie)
		{
			leftOffset += 1
		}
		crossMonthObj.left = leftOffset
		crossMonthObj.top =	parseInt(crossobj.top) + 19

		hideElement( 'SELECT', document.getElementById("selectMonth") );
		hideElement( 'APPLET', document.getElementById("selectMonth") );
		document.all.spanMonth.style.borderColor='#666666';
	}

	function popDownMonth()	{
		crossMonthObj.visibility= "hidden";
		document.all.spanMonth.style.borderColor='#D4D0C8';
	}

	/*** Year Pulldown ***/
	function incYear() {
		for	(i=0; i<7; i++){
			newYear	= (i+nStartingYear)+1
			if (newYear==yearSelected)
			{ txtYear =	"&nbsp;<B>"	+ newYear +	"</B>&nbsp;" }
			else
			{ txtYear =	"&nbsp;" + newYear + "&nbsp;" }
			document.getElementById("y"+i).innerHTML = txtYear
		}
		nStartingYear ++;
		bShow=true
	}

	function decYear() {
		for	(i=0; i<7; i++){
			newYear	= (i+nStartingYear)-1
			if (newYear==yearSelected)
			{ txtYear =	"&nbsp;<B>"	+ newYear +	"</B>&nbsp;" }
			else
			{ txtYear =	"&nbsp;" + newYear + "&nbsp;" }
			document.getElementById("y"+i).innerHTML = txtYear
		}
		nStartingYear --;
		bShow=true
	}

	function selectYear(nYear) {
		yearSelected=parseInt(nYear+nStartingYear);
		yearConstructed=false;
		constructCalendar();
		popDownYear();
	}

	function constructYear() {
		popDownMonth()
		sHTML =	""
		if (!yearConstructed) {

			sHTML =	"<tr><td align='center'	onmouseover='this.style.backgroundColor=\"#FFFFFF\"; this.style.borderColor=\"#666666\"' onmouseout='this.style.backgroundColor=\"\"; this.style.borderColor=\"#FFFFFF\"' style='cursor:pointer; border: 1px solid #ffffff;'	onmousedown='clearInterval(intervalID1);intervalID1=setInterval(\"decYear()\",30)' onmouseup='clearInterval(intervalID1)'>-</td></tr>"

			j =	0
			nStartingYear =	yearSelected-3
			for	(i=(yearSelected-3); i<=(yearSelected+3); i++) {
			    
				sName =	i;
				if (i==yearSelected){
					sName =	"<B>" +	sName +	"</B>"
				}

				sHTML += "<tr><td id='y" + j + "' onmouseover='this.style.backgroundColor=\"#CAD2E4\"; this.style.borderColor=\"#666666\"' onmouseout='this.style.backgroundColor=\"\"; this.style.borderColor=\"#FFFFFF\"' style='cursor:pointer; border: 1px solid #ffffff;' bgcolor=#ffffff onclick='selectYear("+j+");event.cancelBubble=true'>&nbsp;" + sName + "&nbsp;</td></tr>"
				j ++;
			}

			sHTML += "<tr><td align='center' onmouseover='this.style.backgroundColor=\"#FFFFFF\"; this.style.borderColor=\"#666666\"' onmouseout='this.style.backgroundColor=\"\"; this.style.borderColor=\"#FFFFFF\"' style='cursor:pointer; border: 1px solid #ffffff;' bgcolor=#ffffff onmousedown='clearInterval(intervalID2);intervalID2=setInterval(\"incYear()\",30)'	onmouseup='clearInterval(intervalID2)'>+</td></tr>"

			document.getElementById("selectYear").innerHTML	= "<table width=44 style='font-family:arial; font-size:11px; border-width:1; border-style:solid; border-color:#666666; border-Top: 0px;' bgcolor='#FFFFFF' onmouseover='clearTimeout(timeoutID2)' onmouseout='clearTimeout(timeoutID2);timeoutID2=setTimeout(\"popDownYear();\",100)' cellspacing=1 cellpadding=0>"	+ sHTML	+ "</table>"

			yearConstructed	= true
		}
	}

	function popDownYear() {
		clearInterval(intervalID1)
		clearTimeout(timeoutID1)
		clearInterval(intervalID2)
		clearTimeout(timeoutID2)
		crossYearObj.visibility= "hidden"
		document.all.spanYear.style.borderColor='#D4D0C8';
	}

	function resetColor(){
	//alert("here");
	document.all.spanMonth.style.borderColor='#D4D0C8';
	document.all.spanYear.style.borderColor='#D4D0C8';
	}
	
	function popUpYear() {
		var	leftOffset

		constructYear()
		crossYearObj.visibility	= (dom||ie)? "visible" : "show"
		leftOffset = parseInt(crossobj.left) + document.getElementById("spanYear").offsetLeft
		if (ie)
		{
			leftOffset += 1
		}
		crossYearObj.left = leftOffset
		crossYearObj.top = parseInt(crossobj.top) +	19
		document.all.spanYear.style.borderColor='#666666';
	}

	/*** calendar ***/
   function WeekNbr(n) {
      year = n.getFullYear();
      month = n.getMonth() + 1;
      if (startAt == 0) {
         day = n.getDate() + 1;
      }
      else {
         day = n.getDate();
      }
 
      a = Math.floor((14-month) / 12);
      y = year + 4800 - a;
      m = month + 12 * a - 3;
      b = Math.floor(y/4) - Math.floor(y/100) + Math.floor(y/400);
      J = day + Math.floor((153 * m + 2) / 5) + 365 * y + b - 32045;
      d4 = (((J + 31741 - (J % 7)) % 146097) % 36524) % 1461;
      L = Math.floor(d4 / 1460);
      d1 = ((d4 - L) % 365) + L;
      week = Math.floor(d1/7) + 1;
 
      return week;
   }

	function constructCalendar () {
		var aNumDays = Array (31,0,31,30,31,30,31,31,30,31,30,31)

		var dateMessage
		var	startDate =	new	Date (yearSelected,monthSelected,1)
		var endDate

		if (monthSelected==1)
		{
			endDate	= new Date (yearSelected,monthSelected+1,1);
			endDate	= new Date (endDate	- (24*60*60*1000));
			numDaysInMonth = endDate.getDate()
		}
		else
		{
			numDaysInMonth = aNumDays[monthSelected];
		}

		datePointer	= 0
		dayPointer = startDate.getDay() - startAt
		
		if (dayPointer<0)
		{
			dayPointer = 6
		}

		sHTML =	"<table	 border=0 style='font-family:verdana;font-size:10px;'><tr>"

		if (showWeekNumber==1)
		{
			sHTML += "<td width=27><b>" + weekString + "</b></td><td width=1 rowspan=7 bgcolor='#d0d0d0' style='padding:0px'><img src='"+imgDir+"divider.gif' width=1></td>"
		}

		for	(i=0; i<7; i++)	{
			sHTML += "<td width='27' align='right'><B>"+ dayName[i]+"</B></td>"
		}
		sHTML +="</tr><tr>"
		
		if (showWeekNumber==1)
		{
			sHTML += "<td align=right>" + WeekNbr(startDate) + "&nbsp;</td>"
		}

		for	( var i=1; i<=dayPointer;i++ )
		{
			sHTML += "<td>&nbsp;</td>"
		}
		for	( datePointer=1; datePointer<=numDaysInMonth; datePointer++ )
		{
			dayPointer++;
			sHTML += "<td align=right>"
			sStyle=styleAnchor
			
			if ((datePointer==odateSelected) &&	(monthSelected==omonthSelected)	&& (yearSelected==oyearSelected))
			{ sStyle+=styleLightBorder }

			sHint = ""
			for (k=0;k<HolidaysCounter;k++)
			{
				if ((parseInt(Holidays[k].d)==datePointer)&&(parseInt(Holidays[k].m)==(monthSelected+1)))
				{
					if ((parseInt(Holidays[k].y)==0)||((parseInt(Holidays[k].y)==yearSelected)&&(parseInt(Holidays[k].y)!=0)))
					{
						sStyle+="background-color:#FFDDDD;"
						sHint+=sHint==""?Holidays[k].desc:"\n"+Holidays[k].desc
					}
				}
			}

			var regexp= /\"/g
			sHint=sHint.replace(regexp,"&quot;")

			dateMessage = "onmousemove='window.status=\""+selectDateMessage.replace("[date]",constructDate(datePointer,monthSelected,yearSelected))+"\"' onmouseout='window.status=\"\"' "

			if ((datePointer==dateNow)&&(monthSelected==monthNow)&&(yearSelected==yearNow))
			{ sHTML += "<b><a "+dateMessage+" title=\"" + sHint + "\" style='"+sStyle+"' href='javascript:dateSelected="+datePointer+";closeCalendar();'><font color=#ff0000>&nbsp;" + datePointer + "</font>&nbsp;</a></b>"}
			else if	(dayPointer % 7 == (startAt * -1)+1)
			{ sHTML += "<a "+dateMessage+" title=\"" + sHint + "\" style='"+sStyle+"' href='javascript:dateSelected="+datePointer + ";closeCalendar();'>&nbsp;<font color=#909090>" + datePointer + "</font>&nbsp;</a>" }
			else if	(dayPointer % 7 == (startAt * -1)+0)
			{ sHTML += "<a "+dateMessage+" title=\"" + sHint + "\" style='"+sStyle+"' href='javascript:dateSelected="+datePointer + ";closeCalendar();'>&nbsp;<font color=#909090>" + datePointer + "</font>&nbsp;</a>" }
			else
			{ sHTML += "<a "+dateMessage+" title=\"" + sHint + "\" style='"+sStyle+"' href='javascript:dateSelected="+datePointer + ";closeCalendar();'>&nbsp;" + datePointer + "&nbsp;</a>" }

			sHTML += ""
			if ((dayPointer+startAt) % 7 == startAt) { 
				sHTML += "</tr><tr>" 
				if ((showWeekNumber==1)&&(datePointer<numDaysInMonth))
				{
					sHTML += "<td align=right>" + (WeekNbr(new Date(yearSelected,monthSelected,datePointer+1))) + "&nbsp;</td>"
				}
			}
		}

		document.getElementById("content").innerHTML   = sHTML
		document.getElementById("spanMonth").innerHTML = "&nbsp;" +	monthName[monthSelected] + "&nbsp;<IMG id='changeMonth' SRC='"+imgDir+"drop1.gif' WIDTH='12' HEIGHT='10' BORDER=0 align=absmiddle>"
		document.getElementById("spanYear").innerHTML =	"&nbsp;" + yearSelected	+ "&nbsp;<IMG id='changeYear' SRC='"+imgDir+"drop1.gif' WIDTH='12' HEIGHT='10' BORDER=0 align=absmiddle>"
	}

	function popUpCalendar(ctl, ctl2, format, frameOffSetLeft, frameOffSetTop) {
		var	leftpos=0
		var	toppos=0
		
	   isShortYearFormat = false;
		if (bPageLoaded){
			
			if ( crossobj.visibility ==	"hidden" ) {
				ctlToPlaceValue	= ctl2
				dateFormat=format;

				formatChar = " "
				aFormat	= dateFormat.split(formatChar)
				
				if (aFormat.length<3)
				{
					formatChar = "/"
					aFormat	= dateFormat.split(formatChar)
					if (aFormat.length<3)
					{
						formatChar = "."
						aFormat	= dateFormat.split(formatChar)
						if (aFormat.length<3)
						{
							formatChar = "-"
							aFormat	= dateFormat.split(formatChar)
							if (aFormat.length<3)
							{
								// invalid date	format
								formatChar=""
							}
						}
					}
				}

				tokensChanged =	0
				if ( formatChar	!= "" ){
					
					// use user's date
					aData =	ctl2.value.split(formatChar)
					
					for	(i=0;i<3;i++)
					{
						if ((aFormat[i]=="d") || (aFormat[i]=="dd"))
						{ 
							dateSelected = parseInt(aData[i], 10)
							tokensChanged ++
						}
						else if	((aFormat[i]=="m") || (aFormat[i]=="mm"))
						{
							monthSelected =	parseInt(aData[i], 10) - 1
							tokensChanged ++
						}
						else if	((aFormat[i]=="yyyy")|| (aFormat[i]=="yy"))
						{
							//For support Short year 28-FEB-2008 JIT
							if (aFormat[i]=="yy") {
						       var strTemp = ""; 
							   isShortYearFormat = true;
							   //Process Year Value 
							   //If short year > 50 is 1950, ortherwise 2050
							   if (aData[i] >= 50) strTemp = "19" + aData[i];
							   else  strTemp = "20" + aData[i];	   
							  
							   aData[i] = parseInt(strTemp);
							   //Process new date format
							   aFormat[i] = "yyyy";
							   dateFormat = aFormat[0] + formatChar + aFormat[1] + formatChar + aFormat[2]; 
							} 
							//--------------------------------------
						
							yearSelected = parseInt(aData[i], 10)
							tokensChanged ++
						}
						else if	((aFormat[i]=="mmm") || (aFormat[i]=="mmmm")) {
							//Support Short Month 28-AUG-2008 
							if (aFormat[i]=="mmmm") {  //Assign Full Month String (MMMM)
								for	(j=0; j<12;	j++)
								{
									if (aData[i]==monthName[j])
									{
										monthSelected=j
										tokensChanged ++ 
									}
								} //end for 
							} else {   //Assign Short Month String (MMM)
								for	(j=0; j<12;	j++)
								{
									if (aData[i]==monthNameShort[j])
									{
										monthSelected=j
										tokensChanged ++
									}
								} //end for 
							} //end else 
							
						} //end else 
					}
					if (tokensChanged != 3 ||isNaN(dateSelected)||isNaN(monthSelected)||isNaN(yearSelected) && (ctl2.value != "")) 
					{  
					    aData =	ctl2.value;
						if (aData != "")
						{
				            dateSelected = parseInt(aData.substring(6,8));
				            monthSelected = parseInt(aData.substring(4,6) - 1);
				            yearSelected = parseInt(aData.substring(0,4));
				            tokensChanged = 3;
						}
					}
				
				}
				else
				{
				    aData =	ctl2.value;
					if (aData != "")
					{
				        dateSelected = parseInt(aData.substring(6,8));
				        monthSelected = parseInt(aData.substring(4,6) - 1);
				        yearSelected = parseInt(aData.substring(0,4));
				        tokensChanged = 3;
					}
				}

				if ((tokensChanged!=3)||isNaN(dateSelected)||isNaN(monthSelected)||isNaN(yearSelected))
				{
					dateSelected = dateNow
					monthSelected =	monthNow
					theDate = new Date()
                    yearSelected = theDate.getFullYear()
				}

				odateSelected=dateSelected
				omonthSelected=monthSelected
				oyearSelected=yearSelected

				aTag = ctl
				do {
					aTag = aTag.offsetParent;
					leftpos	+= aTag.offsetLeft;
					toppos += aTag.offsetTop;
				} while(aTag.tagName!="BODY");

				crossobj.left =	fixedX==-1 ? ctl.offsetLeft + leftpos + frameOffSetLeft : fixedX
				crossobj.top = fixedY==-1 ? ctl.offsetTop + toppos + frameOffSetTop + ctl.offsetHeight : fixedY
				constructCalendar (1, monthSelected, yearSelected);
				crossobj.visibility=(dom||ie)? "visible" : "show"

				hideElement( 'SELECT', document.getElementById("calendar") );
				hideElement( 'APPLET', document.getElementById("calendar") );			

				bShow = true;
			}
		
			else
			{
				hideCalendar()
				if (ctlNow!=ctl) {popUpCalendar(ctl, ctl2, format, leftpos, toppos)}
			}
			ctlNow = ctl
		}
	}

//	document.onkeypress = function hidecal1 () { 
//		var aKey = event.keyCode
//		if (aKey==27) 
//		{
//			hideCalendar()
//		}
//	}
//	
	document.onclick = function hidecal2 () { 		
		if (!bShow)
		{
			hideCalendar()
		}
		bShow = false
	}

	// Initialize the Calendar object when the DOM is ready
	YAHOO.util.Event.onDOMReady( function() { dbqwikCalendarStd1init(); } );  