<html>
<head>
<title>Voters Control Panel</title>
<link rel="icon" type="image/png" href="../images/icons/favicon.png"/>
<meta name="generator" content="dbQwikSite Ecommerce"><meta name="dbQwikSitePE" content="QSFREEPE">
<style type="text/css">
<!--
.fontnormal {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 12px;
}
.fontheader {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 20px;
}
-->
  </style>
</head>
<body>
<p align="center" class="fontheader"><strong>Voters
  Control Panel</strong></p>
<div>
<div id="nav" align="center">
	<ul>
		<a href="position.php">|Position Info|</a>
		<a href="candidate.php">|Candidate Info|</a>
		<a href="students.php">|Voters Info|</a>
		<a href="tally.php">|Vote Analisys|</a>
        
	</ul>
</div>
<table qwsid="535.TExpHtml.sitegroupcontrolpanel.htmlsite  BgColor="#D4D4D4" cellspacing="1" cellpadding="2" width="320" border="0" align="center" BorderColor="#000020">
<tbody>
        <tr  BgColor="#FFFFE1">
          <td height="40" class="fontnormal">&nbsp;&nbsp;&nbsp;&nbsp;Voters Data</td>
          <td height="40" align="center" valign="middle"><a href="./students.php"><img src="./images/bt_data.gif" border="0"  onerror="this.onerror=null;this.src='./images/qs_nopicture.gif';" ></td>
        </tr>
        <tr  BgColor="#FFFFE1">
          <td height="40" class="fontnormal">&nbsp;&nbsp;&nbsp;&nbsp;Find Voter</td>
          <td height="40" align="center" valign="middle"><a href="./students_search.php"><img src="./images/bt_search.gif" border="0"  onerror="this.onerror=null;this.src='./images/qs_nopicture.gif';" ></td>
        </tr>
        <tr  BgColor="#FFFFE1">
          <td height="40" class="fontnormal">&nbsp;&nbsp;&nbsp;&nbsp;Add Voter</td>
          <td height="40" align="center" valign="middle"><a href="./students_add.php"><img src="./images/bt_qsadd_new.gif" border="0"  onerror="this.onerror=null;this.src='./images/qs_nopicture.gif';" ></td>
        </tr>
        
</tbody>
</table>
</div>
</body>
</html>
